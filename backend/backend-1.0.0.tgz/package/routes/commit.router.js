const express = require("express");
const commitController = require("../controllers/commitController");
const authMiddleware = require("../middleware/authMiddleware");
const upload = require("../middleware/uploadMiddleware");

const commitRouter = express.Router();

// Create commit (requires auth)
commitRouter.post(
  "/commit/create",
  authMiddleware,
  upload.array("files"),
  commitController.createCommit
);

// Read-only commit data
commitRouter.get("/commit/repo/:repoId", commitController.getRepositoryCommits);
commitRouter.get("/repo/files/:repoId", commitController.getRepositoryFiles);
commitRouter.get("/repo/tree/:repoId", commitController.getRepositoryFileTree);

// Delete file (creates a new commit) – requires auth
commitRouter.delete(
  "/repo/file/delete",
  authMiddleware,
  commitController.deleteFile
);

module.exports = commitRouter;
