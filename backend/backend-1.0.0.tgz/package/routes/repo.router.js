const express = require("express");
const repoController = require("../controllers/repoController");
const authMiddleware = require("../middleware/authMiddleware");

const repoRouter = express.Router();

// Public repository endpoints
repoRouter.get("/repo/all", repoController.getAllRepository);
repoRouter.get("/repo/:id", repoController.fetchRepositoryById);
repoRouter.get("/repo/name/:name", repoController.fetchRepositoryByName);
repoRouter.get("/repo/search/:term", repoController.searchRepositories);

// Repositories for a specific user (requires auth)
repoRouter.get(
  "/repo/user/:userId",
  authMiddleware,
  repoController.fetchRepositoriesByCurrentUser
);

// Create / update / delete repo (requires auth)
repoRouter.post(
  "/repo/create",
  authMiddleware,
  repoController.createRepository
);
repoRouter.put(
  "/repo/update/:id",
  authMiddleware,
  repoController.updateRepositoryByID
);
repoRouter.delete(
  "/repo/delete/:id",
  authMiddleware,
  repoController.deleteRepositoryByID
);

// Toggle visibility (requires auth)
repoRouter.patch(
  "/repo/toggel/:id",
  authMiddleware,
  repoController.toggelVisibilityByID
);

// ⭐ STAR SYSTEM (requires auth)
repoRouter.patch(
  "/repo/star/:id",
  authMiddleware,
  repoController.toggleStarRepository
);

// 👀 WATCH SYSTEM (requires auth)
repoRouter.patch(
  "/repo/watch/:id",
  authMiddleware,
  repoController.toggleWatchRepository
);

// ⭐ GET USER STARRED REPOS (requires auth)
repoRouter.get(
  "/repo/starred/:userId",
  authMiddleware,
  repoController.getStarredRepositories
);

module.exports = repoRouter;
