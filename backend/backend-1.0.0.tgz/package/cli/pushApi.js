const fs = require("fs");
const path = require("path");
const axios = require("axios");
const FormData = require("form-data");

function shouldIgnore(relPath) {
  const p = relPath.replaceAll("\\", "/");
  if (p.startsWith(".git/")) return true;
  if (p.startsWith("node_modules/")) return true;
  if (p.startsWith("dist/")) return true;
  if (p.startsWith("build/")) return true;
  if (p.startsWith(".AbhayGit/")) return true;
  if (p.startsWith(".cursor/")) return true;
  if (p === ".env") return true;
  return false;
}

function walkFiles(rootDir) {
  const out = [];
  const stack = [rootDir];
  while (stack.length) {
    const cur = stack.pop();
    const entries = fs.readdirSync(cur, { withFileTypes: true });
    for (const e of entries) {
      const abs = path.join(cur, e.name);
      const rel = path.relative(rootDir, abs).replaceAll("\\", "/");
      if (shouldIgnore(rel)) continue;
      if (e.isDirectory()) {
        stack.push(abs);
      } else if (e.isFile()) {
        out.push({ abs, rel });
      }
    }
  }
  return out;
}

async function pushApi({ backendUrl, repoId, token, message, rootPath }) {
  if (!backendUrl) throw new Error("backendUrl is required");
  if (!repoId) throw new Error("repoId is required");
  if (!token) throw new Error("token is required");

  const resolvedRoot = path.resolve(process.cwd(), rootPath || ".");
  const files = walkFiles(resolvedRoot);
  if (files.length === 0) throw new Error("No files found to push");

  const form = new FormData();
  form.append("repoId", repoId);
  form.append("message", message || "Update files");

  for (const f of files) {
    form.append("files", fs.createReadStream(f.abs), {
      filename: path.basename(f.rel),
    });
    form.append("paths", f.rel);
  }

  const res = await axios.post(`${backendUrl}/commit/create`, form, {
    headers: {
      ...form.getHeaders(),
      Authorization: `Bearer ${token}`,
    },
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });

  return res.data;
}

module.exports = { pushApi };

