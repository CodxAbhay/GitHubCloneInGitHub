const { v4: uuidv4 } = require("uuid");
const Commit = require("../models/commitModel");
const Repository = require("../models/repoModel");
const { s3, s3_bucket } = require("../config/aws_config");
const path = require("path");

/* ===============================
   CREATE COMMIT
================================ */

async function createCommit(req, res) {
  const { repoId, message } = req.body;

  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({
        success: false,
        message: "No files uploaded",
      });
    }

    const repository = await Repository.findById(repoId);

    if (!repository) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    // Permission: only owner or collaborator can push
    const userId = req.user?.id;
    const isOwner =
      userId && repository.owner?.toString?.() === userId.toString();
    const isCollaborator =
      userId &&
      Array.isArray(repository.collaborators) &&
      repository.collaborators.some((c) => c.toString() === userId.toString());

    if (!isOwner && !isCollaborator) {
      return res.status(403).json({
        success: false,
        message: "Forbidden: you do not have write access to this repository",
      });
    }

    const commitId = uuidv4();

    // Get previous commit (for Git-like snapshot behavior)
    const previousCommit = await Commit.findOne({ repository: repoId }).sort({
      createdAt: -1,
    });

    let files = previousCommit ? [...previousCommit.files] : [];

    for (let i = 0; i < req.files.length; i++) {
      const file = req.files[i];

      const originalPath = req.body.paths?.[i] || file.originalname;
      const normalizedPath = String(originalPath).replaceAll("\\", "/");

      console.log("Uploaded file path:", normalizedPath);
      const fileName = path.basename(normalizedPath);
      const filePath = normalizedPath;

      const s3Key = `repos/${repoId}/${commitId}/${filePath}`;

      const uploadParams = {
        Bucket: s3_bucket,
        Key: s3Key,
        Body: file.buffer,
      };

      await s3.upload(uploadParams).promise();

      const signedUrl = s3.getSignedUrl("getObject", {
        Bucket: s3_bucket,
        Key: s3Key,
        Expires: 60 * 60 * 24 * 365,
      });

      files.push({
        fileName,
        filePath,
        url: signedUrl,
      });
    }

    const commit = new Commit({
      repository: repoId,
      commitMessage: message,
      commitId: commitId,
      files: files,
    });

    await commit.save();

    res.status(201).json({
      success: true,
      data: commit,
    });
  } catch (error) {
    console.error("Create Commit Error:", error);

    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

/* ===============================
   GET REPOSITORY COMMITS
================================ */

async function getRepositoryCommits(req, res) {
  const { repoId } = req.params;

  try {
    const commits = await Commit.find({
      repository: repoId,
    }).sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: commits,
    });
  } catch (error) {
    console.error("Get commits error:", error);

    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

/* ===============================
   GET REPOSITORY FILES
================================ */

async function getRepositoryFiles(req, res) {
  const { repoId } = req.params;

  try {
    const latestCommit = await Commit.findOne({ repository: repoId }).sort({
      createdAt: -1,
    });

    if (!latestCommit) {
      return res.status(404).json({
        success: false,
        message: "No commits found",
      });
    }

    const files = latestCommit.files.map((file) => {
      return {
        fileName: file.fileName || file.filePath,
        filePath: file.filePath || file.fileName,
        url: file.url,
      };
    });

    res.status(200).json({
      success: true,
      files,
    });
  } catch (error) {
    console.error("Fetch files error:", error);

    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

/* ===============================
   GET FILE TREE (GitHub style)
================================ */

async function getRepositoryFileTree(req, res) {
  const { repoId } = req.params;

  try {
    const latestCommit = await Commit.findOne({ repository: repoId }).sort({
      createdAt: -1,
    });

    if (!latestCommit) {
      return res.json({
        success: true,
        tree: {},
      });
    }

    const tree = {};

    for (const file of latestCommit.files) {
      const filePath = file.filePath || file.fileName;

      if (!filePath) continue;

      const parts = filePath.split("/");

      let current = tree;

      parts.forEach((part, index) => {
        if (!current[part]) {
          if (index === parts.length - 1) {
            current[part] = {
              type: "file",
              url: file.url,
            };
          } else {
            current[part] = {};
          }
        }

        current = current[part];
      });
    }

    res.json({
      success: true,
      tree,
    });
  } catch (error) {
    console.error("File tree error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to load repository tree",
    });
  }
}

async function deleteFile(req,res){

  const {repoId,filePath} = req.body;

  try{
    const repository = await Repository.findById(repoId);
    if (!repository) {
      return res.status(404).json({ success: false, message: "Repository not found" });
    }

    const userId = req.user?.id;
    const isOwner =
      userId && repository.owner?.toString?.() === userId.toString();
    const isCollaborator =
      userId &&
      Array.isArray(repository.collaborators) &&
      repository.collaborators.some((c) => c.toString() === userId.toString());

    if (!isOwner && !isCollaborator) {
      return res.status(403).json({
        success: false,
        message: "Forbidden: you do not have write access to this repository",
      });
    }

    const previousCommit = await Commit
      .findOne({repository:repoId})
      .sort({createdAt:-1});

    if(!previousCommit){
      return res.status(404).json({
        success:false,
        message:"No commits found"
      });
    }

    const newFiles = previousCommit.files.filter(
      f => f.filePath !== filePath
    );

    const commit = new Commit({
      repository:repoId,
      commitMessage:`Delete ${filePath}`,
      commitId:uuidv4(),
      files:newFiles
    });

    await commit.save();

    res.json({
      success:true
    });

  }catch(err){

    console.error(err);

    res.status(500).json({
      success:false
    });

  }

}

module.exports = {
  createCommit,
  getRepositoryCommits,
  getRepositoryFiles,
  getRepositoryFileTree,
  deleteFile,
};
