const mongoose = require("mongoose");
const Repository = require("../models/repoModel");
const User = require("../models/userModel");
const Issue = require("../models/issueModel");

// ===================================
// CREATE REPOSITORY 
// ===================================
async function createRepository(req, res) {
  const { owner, name, issues, content, description, visibility } = req.body;

  try {
    if (!owner || !name) {
      return res.status(400).json({
        success: false,
        message: "Owner and name are required",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(owner)) {
      return res.status(400).json({
        success: false,
        message: "Invalid owner ID",
      });
    }

    const userExists = await User.findById(owner);
    if (!userExists) {
      return res.status(404).json({
        success: false,
        message: "Owner not found",
      });
    }

    const newRepository = new Repository({
      name,
      description,
      content,
      visibility,
      owner,
      issues,
    });

    const savedRepository = await newRepository.save();

    // attach repository to user document for quick lookups
    await User.findByIdAndUpdate(owner, {
      $addToSet: { repositories: savedRepository._id },
    });

    res.status(201).json({
      success: true,
      data: savedRepository,
    });

  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: "Repository name already exists",
      });
    }

    console.error("Create Repository Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// GET ALL REPOSITORIES (public only)
// ===================================
async function getAllRepository(req, res) {
  try {
    // only return public repositories here
    const repositories = await Repository.find({ visibility: true })
      .populate("owner", "username email")
      .populate("issues");

    res.status(200).json({
      success: true,
      data: repositories,
    });

  } catch (error) {
    console.error("Get All Repository Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// FETCH REPOSITORY BY ID (honours visibility)
// ===================================
async function fetchRepositoryById(req, res) {
  const { id } = req.params;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid repository ID",
      });
    }

    const repository = await Repository.findById(id)
      .populate("owner", "username email")
      .populate("issues");

    if (!repository) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    // hide private repositories from generic fetch
    if (repository.visibility === false) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    res.status(200).json({
      success: true,
      data: repository,
    });

  } catch (error) {
    console.error("Fetch Repository By ID Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// FETCH REPOSITORY BY NAME
// ===================================
async function fetchRepositoryByName(req, res) {
  const { name } = req.params;

  try {
    const repository = await Repository.findOne({ name })
      .populate("owner", "username email")
      .populate("issues");

    if (!repository) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    res.status(200).json({
      success: true,
      data: repository,
    });

  } catch (error) {
    console.error("Fetch Repository By Name Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// SEARCH REPOSITORIES (by name, public only)
// ===================================
async function searchRepositories(req, res) {
  const { term } = req.params;

  try {
    const regex = new RegExp(term, "i");

    const repositories = await Repository.find({
      visibility: true,
      name: { $regex: regex },
    })
      .populate("owner", "username email")
      .populate("issues");

    res.status(200).json({
      success: true,
      data: repositories,
    });
  } catch (error) {
    console.error("Search Repositories Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// FETCH REPOSITORIES BY CURRENT USER
// ===================================
async function fetchRepositoriesByCurrentUser(req, res) {
  const { userId } = req.params;

  try {
    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid user ID",
      });
    } 

    const repositories = await Repository.find({ owner: userId });

    res.status(200).json({
      success: true,
      data: repositories,
    });

  } catch (error) {
    console.error("Fetch Repositories By Current User Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// UPDATE REPOSITORY BY ID
// ===================================
async function updateRepositoryByID(req, res) {
  const { id } = req.params;
  const updates = req.body;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid repository ID",
      });
    }

    const repository = await Repository.findById(id);

    if (!repository) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    // Optional: restrict owner-only update
    if (updates.owner && updates.owner !== repository.owner.toString()) {
      return res.status(403).json({
        success: false,
        message: "You cannot change repository owner",
      });
    }

    Object.assign(repository, updates);
    const updatedRepository = await repository.save();

    res.status(200).json({
      success: true,
      data: updatedRepository,
    });

  } catch (error) {
    console.error("Update Repository Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// TOGGLE VISIBILITY
// ===================================
async function toggelVisibilityByID(req, res) {
  const { id } = req.params;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid repository ID",
      });
    }

    const repository = await Repository.findById(id);

    if (!repository) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    repository.visibility = !repository.visibility;
    await repository.save();

    res.status(200).json({
      success: true,
      message: `Repository is now ${
        repository.visibility ? "Public" : "Private"
      }`,
      data: repository,
    });

  } catch (error) {
    console.error("Toggle Visibility Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// DELETE REPOSITORY
// ===================================
async function deleteRepositoryByID(req, res) {
  const { id } = req.params;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid repository ID",
      });
    }

    const repository = await Repository.findByIdAndDelete(id);

    if (!repository) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Repository deleted successfully",
    });

  } catch (error) {
    console.error("Delete Repository Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// TOGGLE STAR REPOSITORY
// ===================================
async function toggleStarRepository(req,res){

  const { id } = req.params;
  const { userId } = req.body;

  try{

    if(!mongoose.Types.ObjectId.isValid(id)){
      return res.status(400).json({
        success:false,
        message:"Invalid repository ID"
      });
    }

    if(!mongoose.Types.ObjectId.isValid(userId)){
      return res.status(400).json({
        success:false,
        message:"Invalid user ID"
      });
    }

    const repository = await Repository.findById(id);

    if(!repository){
      return res.status(404).json({
        success:false,
        message:"Repository not found"
      });
    }

    const alreadyStarred = repository.stars.includes(userId);

    if(alreadyStarred){

      repository.stars = repository.stars.filter(
        star => star.toString() !== userId
      );

    }else{

      repository.stars.push(userId);

    }

    await repository.save();

    res.status(200).json({
      success:true,
      starred:!alreadyStarred,
      starsCount:repository.stars.length
    });

  }catch(error){

    console.error("Toggle Star Error:",error);

    res.status(500).json({
      success:false,
      message:"Internal Server Error"
    });

  }

}

// ===================================
// TOGGLE WATCH REPOSITORY
// ===================================
async function toggleWatchRepository(req, res) {
  const { id } = req.params;
  const { userId } = req.body;

  try {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid repository ID",
      });
    }

    if (!mongoose.Types.ObjectId.isValid(userId)) {
      return res.status(400).json({
        success: false,
        message: "Invalid user ID",
      });
    }

    const repository = await Repository.findById(id);

    if (!repository) {
      return res.status(404).json({
        success: false,
        message: "Repository not found",
      });
    }

    const alreadyWatching = repository.watchers.includes(userId);

    if (alreadyWatching) {
      repository.watchers = repository.watchers.filter(
        (watcher) => watcher.toString() !== userId,
      );
    } else {
      repository.watchers.push(userId);
    }

    await repository.save();

    res.status(200).json({
      success: true,
      watching: !alreadyWatching,
      watchersCount: repository.watchers.length,
    });
  } catch (error) {
    console.error("Toggle Watch Error:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
}

// ===================================
// FETCH STARRED REPOSITORIES
// ===================================
// async function fetchStarredRepositories(req,res){

//   const { userId } = req.params;

//   try{

//     if(!mongoose.Types.ObjectId.isValid(userId)){
//       return res.status(400).json({
//         success:false,
//         message:"Invalid user ID"
//       });
//     }

//     const repositories = await Repository.find({
//       stars:userId
//     }).populate("owner","username email");

//     res.status(200).json({
//       success:true,
//       data:repositories
//     });

//   }catch(error){

//     console.error("Fetch Starred Repo Error:",error);

//     res.status(500).json({
//       success:false,
//       message:"Internal Server Error"
//     });

//   }

// }


// ===================================
// GET STARRED REPOSITORIES
// ===================================
async function getStarredRepositories(req, res) {

  const { userId } = req.params;

  try {

    const repositories = await Repository.find({
      stars: userId
    })
      .populate("owner", "username email")
      .populate("issues");

    res.status(200).json({
      success: true,
      data: repositories
    });

  } catch (error) {

    console.error("Get Starred Repositories Error:", error);

    res.status(500).json({
      success: false,
      message: "Internal Server Error"
    });

  }
}

module.exports = {
  createRepository,
  getAllRepository,
  fetchRepositoryById,
  fetchRepositoryByName,
  searchRepositories,
  fetchRepositoriesByCurrentUser,
  updateRepositoryByID,
  toggelVisibilityByID,
  deleteRepositoryByID,
  toggleStarRepository,
  toggleWatchRepository,
  // fetchStarredRepositories,
  getStarredRepositories,

};