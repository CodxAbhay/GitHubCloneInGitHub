const mongoose = require("mongoose");
const { Schema } = mongoose;


const commitSchema = new mongoose.Schema({

  repository: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Repository",
    required: true
  },

  commitMessage: {
    type: String,
    required: true
  },

  commitId: {
    type: String,
    required: true
  },

  files: [
    {
      fileName: String,
      filePath: String,
      url: String
    }
  ],

  createdAt: {
    type: Date,
    default: Date.now
  }

});


const Commit = mongoose.model("Commit",commitSchema);

module.exports = Commit;